# Bluetooth-Attendance

A simple web app to automate the recording of attendance via bluetooth using a raspberry pi.


# Installation

To use this project, your computer needs:

1) Python 2 or 3
2) Pip Package Manager
3) Flask
4) Celery


# Running the app

pyhton app.py
